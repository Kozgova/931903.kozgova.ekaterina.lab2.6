﻿using Microsoft.AspNetCore.Identity;

namespace Lab6.Models
{
    // Add profile data for application users by adding properties to the ApplicationUser class
    public class ApplicationUser : IdentityUser
    {
    }
}
