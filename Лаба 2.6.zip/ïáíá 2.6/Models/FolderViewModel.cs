﻿namespace Lab6.Models
{
    public class FolderViewModel
    {
        public String Name { get; set; }
        public Guid? FolderId { get; set; }
    }
}
