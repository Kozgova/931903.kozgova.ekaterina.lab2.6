﻿namespace Lab6.Models
{
    public static class ApplicationRoles
    {
        public const String Administrators = nameof(ApplicationRoles.Administrators);
    }
}
